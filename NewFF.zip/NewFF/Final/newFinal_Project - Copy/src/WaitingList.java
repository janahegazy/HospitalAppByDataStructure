import java.util.*;

public class WaitingList {
    private PriorityQueue queue;

    public WaitingList(String queueFilePath, String patientFilePath) {
        this.queue = new PriorityQueue(queueFilePath, patientFilePath);
    }

    public void addToWaitingList(int patientId, int injuryPriority) {
        PatientPriority patientPriority = new PatientPriority(patientId, injuryPriority);
        queue.insert(patientId, injuryPriority);
    }

    public PatientPriority removeFromWaitingList() {
        return queue.extractMin();
    }

    public List<PatientPriority> getWaitingList() {
        List<PatientPriority> waitingList = new ArrayList<>();
        while (!queue.isEmpty()) {
            waitingList.add(queue.extractMin());
        }
        return waitingList;
    }

    public String loadPatientFromFile(int id) {
        return queue.loadPatientDetails(id);
    }


}
