import java.io.*;
import java.util.*;

public class Patient implements Comparable<Patient>{

    static Scanner input = new Scanner(System.in);
    private int priority;


    private String Email;
    private String Password;
    private String name;
    private int age;
    private String medicalHistory;
    private List<String> visitRecords;




    private String address;
    private int phoneNumber;
    private int relativeNumber;

    public Patient(String email, String password, String name, int age, int i, String medicalHistory, String address, int phoneNumber, int relativeNumber) {
        Email = email;
        Password = password;
        this.name = name;
        this.age = age;
        this.medicalHistory = medicalHistory;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.relativeNumber = relativeNumber;
    }

    public Patient(){

    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getRelativeNumber() {
        return relativeNumber;
    }

    public void setRelativeNumber(int relativeNumber) {
        this.relativeNumber = relativeNumber;
    }


    public String getMedicalHistory() {
        return medicalHistory;
    }

    public void setMedicalHistory(String medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

    public List<String> getVisitRecords() {
        return visitRecords;
    }

    public void setVisitRecords(List<String> visitRecords) {
        this.visitRecords = visitRecords;
    }

    public int getIDForReport() {
        String PatientFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient";
        int newID = 1;

        try (BufferedReader reader = new BufferedReader(new FileReader(PatientFilePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length > 0) {
                    try {
                        int currentID = Integer.parseInt(parts[3].trim());
                        newID = Math.max(newID, currentID);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid appointment ID format: " + parts[0]);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading the appointment file: " + e.getMessage());
        }

        return newID;
    }
    public int getPatientID() {
        String patientFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient"; // Path to the patient file
        Random random = new Random();
        HashSet<Integer> existingIDs = new HashSet<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(patientFilePath));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length > 3) { // Assuming patientID is at index 3
                    try {
                        int existingID = Integer.parseInt(parts[3]);
                        existingIDs.add(existingID);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid patient ID format in file: " + parts[3]);
                    }
                }
            }

            reader.close();
        } catch (IOException e) {
            System.out.println("Error reading the patient file: " + e.getMessage());
        }

        // Generate a random unique patient ID
        int newPatientID;
        do {
            newPatientID = 10000 + random.nextInt(90000); // Random ID between 10000 and 99999
        } while (existingIDs.contains(newPatientID));

        return newPatientID;
    }

    @Override
    public int compareTo(Patient o) {
        return 0;
    }








    public void updateContactInfo(String email, String password, String newAddress, int newPhoneNumber, int newRelativeNumber) {
        File file = new File("C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient");

        // Reading the original file and updating contact info
        try {
            // Read all lines from the file
            BufferedReader reader = new BufferedReader(new FileReader(file));
            StringBuilder fileContent = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                // Check if this is the patient we want to update (match by email and password)
                if (parts[0].equalsIgnoreCase(email) && parts[1].equals(password)) {
                    // Create the new contact info as a single string
                    String newContactInfo = newAddress + "," + newPhoneNumber + "," + newRelativeNumber;
                    parts[6] = newContactInfo; // Update the contactInfo field
                }

                // Append the updated line to the content
                fileContent.append(String.join(",", parts)).append("\n");
            }

            // Close the reader after processing all lines
            reader.close();

            // Write the updated content back to the same file
            FileWriter writer = new FileWriter(file);
            writer.write(fileContent.toString());
            writer.close();

            System.out.println("Contact information updated successfully.");
        } catch (IOException e) {
            System.out.println("Error updating contact information: " + e.getMessage());
        }
    }

    public void getPatientInfo() {
        String patientFilePath = "BC:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient";  // Path to the patient file

        try  {
            BufferedReader reader = new BufferedReader(new FileReader(patientFilePath));

            String line;

            // Read through the file line by line
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                // Check if the patient's email and password match
                if (parts[0].equalsIgnoreCase(Email) && parts[1].equals(Password)) {
                    // Print the patient information (up to index 8)
                    System.out.println("Email: " + parts[0]);
                    System.out.println("Password: " + parts[1]);
                    System.out.println("Name: " + parts[2]);
                    System.out.println("Patient ID: " + parts[3]);
                    System.out.println("Age: " + parts[4]);
                    System.out.println("Medical History: " + parts[5]);
                    System.out.println("Contact Info: " + parts[6]);
                    System.out.println("Appointments: " + parts[7]);
                    return;  // Return true when the patient is found
                }
            }

            // If no matching patient found, return false

        } catch (IOException e) {
            System.out.println("Error reading the patient file: " + e.getMessage());
        }

    }
public String toString(){
         return Email + "," + Password + "," + name + "," +getPatientID()  + "," + age + "," + medicalHistory + "," + address + "," + phoneNumber + "," + relativeNumber;
}
}







