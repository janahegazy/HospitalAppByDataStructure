import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Appointment {
    private  static Patient patient;
    private String date;
    private String time;
    static double amount=100;
    private String status;
    private String department;
    public Appointment(int appointmentID, Patient patient, String date, String time, String status) {
        Appointment.patient = patient;
        this.date = date;
        this.time = time;
        this.status = status;
    }
    public Appointment(){

        this.status = "Scheduled";
    }
    public int getAppointmentID() {
        String appointmentFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Appointment";
        int newAppointmentID = 1;

        try (BufferedReader reader = new BufferedReader(new FileReader(appointmentFilePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length > 0) {
                    try {
                        int currentID = Integer.parseInt(parts[0].trim());
                        newAppointmentID = Math.max(newAppointmentID, currentID);
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid appointment ID format: " + parts[0]);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading the appointment file: " + e.getMessage());
        }

        return newAppointmentID;
    }

    public static Patient getPatient() {
        return patient;
    }

    public static void setPatient(Patient patient) {
        Appointment.patient = patient;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    public boolean schedule(Patient patient, Appointment appointment) {
        String patientFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient"; // Path to the patient file
        String appointmentFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Appointment"; // Path to the appointments file
        boolean appointmentScheduled = false;
        boolean patientFound = false;

        try {
            // Read the patient file
            BufferedReader reader = new BufferedReader(new FileReader(patientFilePath));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                // Ensure valid patient data with at least 9 fields (index 8 for appointments)
                if (parts.length < 8) {
                    sb.append(line).append("\n");
                    continue;
                }

                // Check if the email and password match the patient's credentials
                if (parts[0].equalsIgnoreCase(patient.getEmail()) && parts[1].equals(patient.getPassword())) {
                    patientFound = true;

                    // Handle the appointments field at index 8
                    String appointments = (parts.length > 8 && parts[8] != null) ? parts[8] : "";

                    // Check for existing appointments at the same date and time
                    if (!appointments.isEmpty()) {
                        String[] patientAppointments = appointments.split(",");
                        for (String bookedAppointment : patientAppointments) {
                            String[] appointmentDetails = bookedAppointment.split(";");
                            if (appointmentDetails.length >= 5 &&
                                    appointmentDetails[2].equals(appointment.getDate()) &&
                                    appointmentDetails[3].equals(appointment.getTime())) {
                                System.out.println("You have already booked an appointment for this date and time.");
                                return false;
                            }
                        }
                    }

                    // Format the new appointment details
                    String newAppointmentDetails = appointment.getAppointmentID() + ";" +
                            appointment.getDepartment() + ";" +
                            appointment.getDate() + ";" +
                            appointment.getTime() + ";" +
                            appointment.getStatus();

                    // Update the appointments field
                    if (appointments.isEmpty()) {
                        appointments = newAppointmentDetails;
                    } else {
                        appointments += "," + newAppointmentDetails; // Separate multiple appointments by commas
                    }

                    // Ensure the parts array has enough fields to store appointments
                    if (parts.length < 9) {
                        parts = Arrays.copyOf(parts, 9);
                    }
                    parts[8] = appointments; // Assign updated appointments to index 8

                    // Save the appointment in the Appointments file
                    FileWriter appointmentWriter = new FileWriter(appointmentFilePath, true);
                    appointmentWriter.write(appointment.getAppointmentID() + "," +
                            patient.getEmail() + "," +
                            appointment.getDepartment() + "," +
                            appointment.getDate() + "," +
                            appointment.getTime() + "," +
                            appointment.getStatus() + "\n");
                    appointmentWriter.close();

                    appointmentScheduled = true;
                }

                // Append the updated or unchanged record to the string builder
                sb.append(String.join(",", parts)).append("\n");
            }

            reader.close();

            if (!patientFound) {
                System.out.println("No matching patient found.");
                return false;
            }

            if (!appointmentScheduled) {
                System.out.println("Appointment not scheduled. Please try again.");
                return false;
            }

            // Write the updated patient details back to the file
            FileWriter writer = new FileWriter(patientFilePath);
            writer.write(sb.toString());
            writer.close();

            System.out.println("Appointment successfully scheduled!");
            return true;

        } catch (IOException e) {
            System.out.println("Error reading/writing files: " + e.getMessage());
            return false;
        }
    }






    public static boolean cancelAppointment(Patient patient, int appointmentID) {
        String patientFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient"; // Path to the patient file
        String appointmentFilePath = "C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Appointment"; // Path to the appointments file
        boolean appointmentFound = false;
        boolean patientFound = false;

        try {
            // Step 1: Update the Appointment file (remove appointment by appointmentID)
            BufferedReader appointmentReader = new BufferedReader(new FileReader(appointmentFilePath));
            StringBuilder updatedAppointmentRecords = new StringBuilder();
            String line;

            while ((line = appointmentReader.readLine()) != null) {
                String[] parts = line.split(",");

                // Skip the appointment with the specified appointmentID
                if (parts.length > 0 && parts[0].equals(String.valueOf(appointmentID))) {
                    appointmentFound = true;
                    continue; // Skip this line, effectively removing the appointment
                }

                updatedAppointmentRecords.append(line).append("\n");
            }

            appointmentReader.close();

            if (!appointmentFound) {
                System.out.println("Appointment ID not found in the appointments file.");
                return false;
            }

            // Write the updated appointment records back to the file
            FileWriter appointmentWriter = new FileWriter(appointmentFilePath);
            appointmentWriter.write(updatedAppointmentRecords.toString());
            appointmentWriter.close();

            // Step 2: Update the Patient file (remove the appointment from the patient's list)
            BufferedReader patientReader = new BufferedReader(new FileReader(patientFilePath));
            StringBuilder updatedPatientRecords = new StringBuilder();

            while ((line = patientReader.readLine()) != null) {
                String[] parts = line.split(",");

                // Check if the record matches the patient's email and password
                if ((parts[0] + parts[1]).equals(patient.getEmail() + patient.getPassword())) {
                    patientFound = true;

                    // Handle the appointments fields starting from index 8 (index 9, 10, 11, etc.)
                    for (int i = 8; i < parts.length; i++) {
                        // If there's an appointment in the index
                        if (parts[i] != null && !parts[i].isEmpty()) {
                            String[] patientAppointments = parts[i].split(",");

                            StringBuilder updatedAppointments = new StringBuilder();

                            // Loop through the appointments to find and remove the one with the appointmentID
                            for (String bookedAppointment : patientAppointments) {
                                String[] appointmentDetails = bookedAppointment.split(";");

                                // Check if the first element is the appointmentID and remove it
                                if (appointmentDetails.length >= 5 && appointmentDetails[0].equals(Integer.valueOf(appointmentID))) {
                                    // Mark appointment as found, skip this appointment
                                    appointmentFound = true;
                                    continue; // Skip this line, effectively removing the appointment
                                } else {
                                    // Add the remaining appointments to the updated list
                                    if (updatedAppointments.length() > 0) {
                                        updatedAppointments.append(",");
                                    }
                                    updatedAppointments.append(bookedAppointment);
                                }
                            }

                            // If there are remaining appointments, assign them back to the current index
                            if (updatedAppointments.length() > 0) {
                                parts[i] = updatedAppointments.toString(); // Assign the updated list back to the index
                            } else {
                                parts[i] = ""; // If no appointments are left for this index, empty it
                            }

                            // After handling the appointment removal, break out of the loop
                            break;
                        }
                    }

                    updatedPatientRecords.append(String.join(",", parts)).append("\n");
                } else {
                    updatedPatientRecords.append(line).append("\n");
                }
            }

            patientReader.close();

            if (!patientFound) {
                System.out.println("No matching patient found.");
                return false;
            }

            // Write the updated patient records back to the file
            FileWriter patientWriter = new FileWriter(patientFilePath);
            patientWriter.write(updatedPatientRecords.toString());
            patientWriter.close();

            System.out.println("Appointment successfully cancelled!");
            return true;

        } catch (IOException e) {
            System.out.println("Error reading/writing files: " + e.getMessage());
            return false;
        }
    }





}
