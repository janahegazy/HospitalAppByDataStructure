public class PatientPriority {
    private int patientId;
    private int injuryPriority;

    public PatientPriority(int patientId, int injuryPriority) {
        this.patientId = patientId;
        this.injuryPriority = injuryPriority;
    }

    public int getPatientId() {
        return patientId;
    }

    public int getInjuryPriority() {
        return injuryPriority;
    }

    @Override
    public String toString() {
        return patientId + "," + injuryPriority;
    }
}
