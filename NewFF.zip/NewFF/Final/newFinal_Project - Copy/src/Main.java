import com.sun.jdi.Value;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Main {
    static Scanner input = new Scanner(System.in);
    public static BinarySearchTree<Patient> patientBST = new BinarySearchTree<>();

    public static void main(String[] args) {
        new HospitalDashBoard();
        System.out.println("Welcome to Hospital: ");
        System.out.println("1. Sign Up 2. Sign In 3. Exit");//button
        int choice = input.nextInt();
        input.nextLine();
        if (choice == 1) {
            patientSignup();
        } else if (choice == 2) {
            patientLogin();
        }


    }

    public static void patientSignup(){
        Patient newPatient = new Patient();
        Appointment appointment=new Appointment();
        System.out.print("Full Name: ");
        newPatient.setName(input.nextLine());
        System.out.print("Age: ");
        newPatient.setAge(input.nextInt());
        input.nextLine();
        System.out.println("Do you have any medicalHistory: ");
        newPatient.setMedicalHistory(input.nextLine());
        System.out.println("Please enter your contactInfo: ");
        System.out.println("Enter address: ");
        newPatient.setAddress(input.nextLine());
        System.out.println("Phone number: ");
        newPatient.setPhoneNumber(Integer.parseInt(input.nextLine()));
        System.out.println("relativeNumber: ");
        newPatient.setRelativeNumber(Integer.parseInt(input.nextLine()));
        System.out.print("Email: ");
        newPatient.setEmail(input.nextLine());
        System.out.print("Password: ");
        newPatient.setPassword(input.nextLine());
        if (registerPatient(newPatient.getEmail(), newPatient.getPassword(), newPatient.getName(), newPatient.getPatientID(), newPatient.getAge(), newPatient.getMedicalHistory(),newPatient.getAddress(), newPatient.getPhoneNumber(), newPatient.getRelativeNumber())){
            System.out.println("1. Book an Appointment 2. Cancel Appointment 3. get Info 4. Update contacts 5. Generate Report 6. Exit");
            int option=input.nextInt();
            input.nextLine();
            while (option!=6){
                switch (option) {
                    case 1 -> {
                        System.out.println("Department:  General / Cardiology / Pediatrics"); // عام او قلب او اطفال
                        appointment.setDepartment(input.nextLine());
                        System.out.println("Enter Preferred Date (yyyy-mm-dd): ");
                        appointment.setDate(input.nextLine());
                        System.out.println("Enter Preferred Time (e.g., 10:30 AM): ");
                        appointment.setTime(input.nextLine());
                        Billing billing=new Billing(String.valueOf(newPatient.getIDForReport()));
                        System.out.println("The appointment amount is "+appointment.amount+"\n Agree to pay? \n (Yes/No)");
                        String ans=input.next();
                        if (ans.equals("No")) break;
                        else {
                            billing.generateBill(appointment.amount);
                            billing.addPayment(appointment.amount);
                        }
                        if (appointment.schedule(newPatient, appointment)) {
                            System.out.println("Appointment booked successfully!");
                        } else {
                            System.out.println("Failed to book appointment. Try a different date/time.");
                        }
                    }
                    case 2 -> {
                        System.out.println("Enter the Appointment ID to cancel: ");
                        int appointmentID = Integer.parseInt(input.nextLine());
                        if (appointment.cancelAppointment(newPatient, appointmentID)) {
                            System.out.println("Appointment canceled successfully.");
                        } else {
                            System.out.println("Failed to cancel appointment or appointment not found.");
                        }
                    }
                    case 3 -> {
                        System.out.println("Your Information: ");
                        newPatient.getPatientInfo();
                    }
                    case 4 -> {
                        newPatient.updateContactInfo(newPatient.getEmail(), newPatient.getPassword(), newPatient.getAddress(), newPatient.getPhoneNumber(),newPatient.getRelativeNumber());
                    }
                    case 5 -> {
                        System.out.println("1. generate Patient Report 2. generate Appointment Report 3.generate Revenue Report");
                        int ch= input.nextInt();
                        if (ch==1){
                            ReportGenerator patientReportGen = new ReportGenerator("PatientReport");
                            patientReportGen.generatePatientReport(String.valueOf(newPatient.getIDForReport()));
                        }
                        else if (ch==2){
                            ReportGenerator appointmentReportGen = new ReportGenerator("AppointmentReport");
                            appointmentReportGen.generateAppointmentReport(String.valueOf(appointment.getAppointmentID()));
                        }
                        else if (ch==3){
                            ReportGenerator revenueReportGen = new ReportGenerator("RevenueReport");
                            revenueReportGen.generateRevenueReport(String.valueOf(newPatient.getIDForReport()));
                        }
                        else System.out.println("Wrong choice");
                    }

                    default -> System.out.println("Invalid option. Try again.");
                }
                System.out.println("1. Book an Appointment 2. Cancel Appointment 3. get Info 4. Update contacts 5. Generate Report 6. Exit");
                    option=input.nextInt();
                    input.nextLine();

            }

        }

    }

    public static boolean registerPatient(String email, String password,String name,int ID,int age,String medicalHistory,String address,int phone,int relativeNumber) {
        Patient newPatient = new Patient(email, password, name, ID, age, medicalHistory,address,phone, relativeNumber);

        // Check for duplicate email
        if (patientBST.contains(newPatient)) {
            System.out.println("Email already exists. Please use a different email.");
            return false;
        }

        // Add to the BST
        patientBST.insert(newPatient);
        System.out.println("Patient registered successfully in BST.");

        // Append to the file
        File file = new File("C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient");
        try (FileWriter fileWriter = new FileWriter(file, true)) {
            fileWriter.write(email + "," + password + "," + name + "," + ID + "," + age + "," + medicalHistory + "," + address +"," + phone+"," +relativeNumber+ "\n");
            System.out.println("Patient saved to file.");
            return true;
        } catch (IOException e) {
            System.out.println("Error writing to patient records: " + e.getMessage());
        }

        return false;
    }



    public static void patientLogin(){
        Appointment appointment = new Appointment();
        Patient newPatient = new Patient();
        System.out.println("Enter your Email: ");
        newPatient.setEmail(input.nextLine());
        System.out.println("Enter your Password: ");
        newPatient.setPassword(input.nextLine());
        if (!patientLogin(newPatient.getEmail(), newPatient.getPassword())) {
            System.out.println("Invalid Email or Password. Please try again.");
        } else {
            System.out.println("1. Book an Appointment 2. Cancel Appointment 3. get Info 4. Update contacts 5. Generate Report 6. Exit");
            int option=input.nextInt();
            input.nextLine();
            while (option!=6){
                switch (option) {
                    case 1 -> {
                        System.out.println("Department:  General / Cardiology / Pediatrics"); // عام او قلب او اطفال
                        appointment.setDepartment(input.nextLine());
                        System.out.println("Enter Preferred Date (yyyy-mm-dd): ");
                        appointment.setDate(input.nextLine());
                        System.out.println("Enter Preferred Time (e.g., 10:30 AM): ");
                        appointment.setTime(input.nextLine());
                        Billing billing=new Billing(String.valueOf(newPatient.getIDForReport()));
                        System.out.println("The appointment amount is "+appointment.amount+"\n Agree to pay? \n (Yes/No)");
                        String ans=input.next();
                        if (ans.equals("No")) break;
                        else {
                            billing.generateBill(appointment.amount);
                            billing.addPayment(appointment.amount);
                        }
                        if (appointment.schedule(newPatient,appointment)) {
                            System.out.println("Appointment booked successfully!");
                        } else {
                            System.out.println("Failed to book appointment. Try a different date/time.");
                        }
                    }
                    case 2 -> {
                        System.out.println("Enter the Appointment ID to cancel: ");
                        int appointmentID = Integer.parseInt(input.nextLine());
                        if (appointment.cancelAppointment(newPatient,appointmentID)) {
                            System.out.println("Appointment canceled successfully.");
                        } else {
                            System.out.println("Failed to cancel appointment or appointment not found.");
                        }
                    }
                    case 3 -> {
                        System.out.println("Reports:");
                        // Implement report generation here
                    }
                    case 4 -> {
                        newPatient.updateContactInfo(newPatient.getEmail(), newPatient.getPassword(), newPatient.getAddress(), newPatient.getPhoneNumber(),newPatient.getRelativeNumber());
                    }
                    case 5 -> {
                        System.out.println("1. generate Patient Report 2. generate Appointment Report 3.generate Revenue Report");
                        int ch= input.nextInt();
                        if (ch==1){
                            ReportGenerator patientReportGen = new ReportGenerator("PatientReport");
                            patientReportGen.generatePatientReport(String.valueOf(newPatient.getIDForReport()));
                        }
                        else if (ch==2){
                            ReportGenerator appointmentReportGen = new ReportGenerator("AppointmentReport");
                            appointmentReportGen.generateAppointmentReport(String.valueOf(appointment.getAppointmentID()));
                        }
                        else if (ch==3){
                            ReportGenerator revenueReportGen = new ReportGenerator("RevenueReport");
                            revenueReportGen.generateRevenueReport(String.valueOf(newPatient.getIDForReport()));
                        }
                        else System.out.println("Wrong choice");
                    }

                }
                System.out.println("1. Book an Appointment 2. Cancel Appointment 3. get Info 4. Update contacts 5. Generate Report 6. Exit");
                option=input.nextInt();
                input.nextLine();
            }

        }
    }

    public static boolean patientLogin(String email, String password) {
        File file = new File("C:\\Users\\Menna tullah mohamed\\OneDrive - Al Alamein University\\Desktop\\Final\\Final\\newFinal_Project - Copy\\src\\Patient");

        try (FileReader myReader = new FileReader(file);
             Scanner scanner = new Scanner(myReader)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split(",");
                if (data[0].equalsIgnoreCase(email) && data[1].equals(password)) {
                    System.out.println("Login successful! Welcome, " + data[2]);
                    return true;
                }
            }

        } catch (IOException e) {
            System.out.println("Error accessing patient records: " + e.getMessage());
        }

        System.out.println("Invalid email or password.");
        return false;
    }
    //

}