import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class BookAppointmentGUI extends JFrame implements ActionListener {
    private JComboBox<String> departmentBox;
    private JTextField dateField, timeField;
    private JButton confirmButton, cancelButton;
    private Patient patient;
    private PatientService patientService;

    public BookAppointmentGUI(Patient patient, PatientService patientService) {
        this.patient = patient;
        this.patientService = patientService;

        ImageIcon image = new ImageIcon("src/ll.jpeg");
        setIconImage(image.getImage());
        setTitle("Book Appointment");
        setSize(400, 300);
        setLayout(new GridLayout(5, 2, 10, 10));
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        add(new JLabel("Department:"));
        departmentBox = new JComboBox<>(new String[]{"General", "Cardiology", "Pediatrics"});
        departmentBox.setPreferredSize(new Dimension(100, 20));
        departmentBox.setFont(new Font("Tahoma", Font.PLAIN, 12));
        add(departmentBox);
        add(new JLabel("Preferred Date (yyyy-mm-dd):"));
        dateField = new JTextField();
        dateField.setPreferredSize(new Dimension(100, 20));
        dateField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        add(dateField);

        add(new JLabel("Preferred Time (e.g., 10:30 AM):"));
        timeField = new JTextField();
        timeField.setPreferredSize(new Dimension(100, 20));
        timeField.setFont(new Font("Tahoma", Font.PLAIN, 12));
        add(timeField);

        confirmButton = new JButton("Confirm");
        confirmButton.setPreferredSize(new Dimension(100, 30));
        confirmButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        confirmButton.addActionListener(this);
        add(confirmButton);
        cancelButton = new JButton("Cancel");
        cancelButton.setPreferredSize(new Dimension(100, 30));
        cancelButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        cancelButton.addActionListener(this);
        add(cancelButton);

        setVisible(true);
    }

        @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == confirmButton) {
            String department = (String) departmentBox.getSelectedItem();
            String date = dateField.getText();
            String time = timeField.getText();

            Appointment appointment = new Appointment();
            appointment.setDepartment(department);
            appointment.setDate(date);
            appointment.setTime(time);

            int paymentResponse = JOptionPane.showConfirmDialog(this,
                    "The appointment amount is " + appointment.amount + ". Agree to pay?",
                    "Payment Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if (paymentResponse == JOptionPane.YES_OPTION) {
                Billing billing = new Billing(String.valueOf(patient.getIDForReport()));
                billing.generateBill(appointment.amount);
                billing.addPayment(appointment.amount);

                if (appointment.schedule(patient, appointment)) {
                    JOptionPane.showMessageDialog(this, "Appointment booked successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to book appointment. Try a different date/time.");
                }
            }
        } else if (e.getSource() == cancelButton) {
            dispose();
        }
    }
}
