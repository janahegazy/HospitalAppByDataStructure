import java.io.*;
import java.util.*;

public class PriorityQueue {
    private List<PatientPriority> heap;
    private int size;
    private String queueFilePath;
    private String patientFilePath;

    public PriorityQueue(String queueFilePath, String patientFilePath) {
        this.heap = new ArrayList<>();
        this.size = 0;
        this.queueFilePath = queueFilePath;
        this.patientFilePath = patientFilePath;
        loadFromFile();
    }

    private int parent(int i) {
        return (i - 1) / 2;
    }

    private int leftChild(int i) {
        return 2 * i + 1;
    }

    private int rightChild(int i) {
        return 2 * i + 2;
    }

    private void swap(int i, int j) {
        PatientPriority temp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, temp);
    }

    public void insert(int patientId, int injuryPriority) {
        heap.add(new PatientPriority(patientId, injuryPriority));
        size++;
        heapifyUp(size - 1);
        saveToFile();
    }

    private void heapifyUp(int index) {
        while (index > 0 && heap.get(index).getInjuryPriority() < heap.get(parent(index)).getInjuryPriority()) {
            swap(index, parent(index));
            index = parent(index);
        }
    }

    public PatientPriority extractMin() {
        if (size == 0) {
            throw new IllegalStateException("Priority Queue is empty");
        }

        PatientPriority min = heap.get(0);
        heap.set(0, heap.get(size - 1));
        heap.remove(size - 1);
        size--;
        heapifyDown(0);
        saveToFile();
        return min;
    }

    private void heapifyDown(int index) {
        int smallest = index;
        int left = leftChild(index);
        int right = rightChild(index);

        if (left < size && heap.get(left).getInjuryPriority() < heap.get(smallest).getInjuryPriority()) {
            smallest = left;
        }

        if (right < size && heap.get(right).getInjuryPriority() < heap.get(smallest).getInjuryPriority()) {
            smallest = right;
        }

        if (smallest != index) {
            swap(index, smallest);
            heapifyDown(smallest);
        }
    }

    public PatientPriority peek() {
        if (size == 0) {
            throw new IllegalStateException("Priority Queue is empty");
        }
        return heap.get(0);
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(queueFilePath))) {
            for (int i = 0; i < heap.size(); i++) {
                PatientPriority patientPriority = heap.get(i);
                writer.write(patientPriority.toString() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }

    public void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(queueFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    int patientId = Integer.parseInt(parts[0]);
                    int injuryPriority = Integer.parseInt(parts[1]);
                    PatientPriority patientPriority = new PatientPriority(patientId, injuryPriority);
                    heap.add(patientPriority);
                    size++;
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading from file: " + e.getMessage());
        }
    }

    public String loadPatientDetails(int patientId) {
        try (BufferedReader reader = new BufferedReader(new FileReader(patientFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (Integer.parseInt(parts[3]) == patientId) {
                    return line;
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading patient details from file: " + e.getMessage());
        }
        return null;
    }
}
