 import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class HospitalDashBoard extends JFrame implements ActionListener {
    private PatientService patientService = new PatientService();
  static Patient patient;
    private JButton Loginbutton;
    private JButton signupButton;

    public HospitalDashBoard() {
        setTitle("AIU Hospital System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(450, 650);
        setLocationRelativeTo(null);
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon backgroundIcon = new ImageIcon("src/pp.png");
                Image backgroundImage = backgroundIcon.getImage();
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        ImageIcon image = new ImageIcon("src/ll.jpeg");
        setIconImage(image.getImage());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        mainPanel.setLayout(new BorderLayout());
        JLabel welcomeLabel = new JLabel("Welcome to AIU Hospital.", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setForeground(Color.BLACK);
        mainPanel.add(welcomeLabel, BorderLayout.NORTH);
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setOpaque(false);
        Loginbutton = new JButton("LOGIN");
        styleButton(Loginbutton);
        signupButton = new JButton("SIGNUP");
        styleButton(signupButton);
        buttonPanel.add(Loginbutton);
        buttonPanel.add(signupButton);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);
        add(mainPanel);
        setVisible(true);
        Loginbutton.addActionListener(this);
        signupButton.addActionListener(this);
    }
    private void styleButton(JButton button) {
        button.setPreferredSize(new Dimension(100, 40));
        button.setBackground(new Color(59, 89, 182));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Tahoma", Font.BOLD, 14));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Loginbutton) {
            showLoginDialog();
        } else if (e.getSource() == signupButton) {
            showSignupDialog();
        }
    }

    private void showLoginDialog() {
        JTextField emailField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);

        JPanel loginPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        loginPanel.add(new JLabel("Email:"));
        loginPanel.add(emailField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        UIManager.put("Button.background", new Color(72, 201, 176));
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.focus", Color.GRAY);
        int result =  JOptionPane.showConfirmDialog(this, loginPanel, "Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (patientService.loginPatient(email, password)) {
                patient = patientService.getPatientByEmail(email);
                if (patient != null) {
                    JOptionPane.showMessageDialog(this, "Login Successful!");
                    System.out.println("Login successfully");
                    System.out.println("Hello " + patient.getEmail());
                    new ShowPatient(patient, patientService);
                } else {
                    JOptionPane.showMessageDialog(this, "Patient not found.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Email or Password. Please try again.");
            }
        }
    }




    private void showSignupDialog() {
        JTextField nameField = new JTextField(20);
        JTextField ageField = new JTextField(20);
        JTextField historyField = new JTextField(20);
        JTextField addressField = new JTextField(20);
        JTextField phoneField = new JTextField(20);
        JTextField relativePhoneField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);

        JPanel signupPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        signupPanel.add(new JLabel("Name:"));
        signupPanel.add(nameField);
        signupPanel.add(new JLabel("Age:"));
        signupPanel.add(ageField);
        signupPanel.add(new JLabel("Medical History:"));
        signupPanel.add(historyField);
        signupPanel.add(new JLabel("Address:"));
        signupPanel.add(addressField);
        signupPanel.add(new JLabel("Phone:"));
        signupPanel.add(phoneField);
        signupPanel.add(new JLabel("Relative Phone:"));
        signupPanel.add(relativePhoneField);
        signupPanel.add(new JLabel("Email:"));
        signupPanel.add(emailField);
        signupPanel.add(new JLabel("Password:"));
        signupPanel.add(passwordField);
        UIManager.put("Button.background", new Color(72, 201, 176));
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.focus", Color.GRAY);
        int result =  JOptionPane.showConfirmDialog(this, signupPanel, "Signup", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            try {
                Patient newPatient = new Patient();
                newPatient.setName(nameField.getText());
                newPatient.setAge(Integer.parseInt(ageField.getText()));
                newPatient.setMedicalHistory(historyField.getText());
                newPatient.setAddress(addressField.getText());
                newPatient.setPhoneNumber(Integer.parseInt(phoneField.getText()));
                newPatient.setRelativeNumber(Integer.parseInt(relativePhoneField.getText()));
                newPatient.setEmail(emailField.getText());
                newPatient.setPassword(new String(passwordField.getPassword()));
                if (Main.registerPatient(newPatient.getEmail(), newPatient.getPassword(), newPatient.getName(), newPatient.getIDForReport(), newPatient.getAge(),newPatient.getMedicalHistory(), newPatient.getAddress(), newPatient.getPhoneNumber(), newPatient.getRelativeNumber())) {
                    JOptionPane.showMessageDialog(this, "Signup Successful!");
                } else {
                    JOptionPane.showMessageDialog(this, "Email already registered!");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input format. Please try again.");
            }
        }
    }
}
