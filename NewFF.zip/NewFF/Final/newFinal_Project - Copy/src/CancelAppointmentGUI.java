    import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

    public class CancelAppointmentGUI extends JFrame implements ActionListener {
        private JTextField appointmentIDField;
        private JButton cancelButton, cancelBtn;
        private Patient patient;
        private PatientService patientService;
        private Appointment appointment;

        public CancelAppointmentGUI(Patient patient, PatientService patientService) {
            this.patient = patient;
            this.patientService = patientService;
            ImageIcon image = new ImageIcon("src/ll.jpeg");
            setIconImage(image.getImage());
            setTitle("Cancel Appointment");
            setSize(400, 200);
            setLayout(new GridLayout(3, 2, 10, 10));
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            add(new JLabel("Enter Appointment ID to cancel:"));
            appointmentIDField = new JTextField();
            add(appointmentIDField);
            cancelButton = new JButton("Cancel Appointment");
            cancelButton.addActionListener(this);
            add(cancelButton);
            cancelBtn = new JButton("Cancel");
            cancelBtn.addActionListener(this);
            add(cancelBtn);
            setLocationRelativeTo(null);
            setVisible(true);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == cancelButton) {
                try {

                    int appointmentID = Integer.parseInt(appointmentIDField.getText());


                    if (Appointment.cancelAppointment(patient, appointmentID)) {
                        JOptionPane.showMessageDialog(this, "Appointment canceled successfully.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Failed to cancel appointment or appointment not found.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid Appointment ID entered. Please try again.");
                }
            } else if (e.getSource() == cancelBtn) {
                dispose();
            }
        }
    }


